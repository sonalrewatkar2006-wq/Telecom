"""Streamlit interface for the trained telecom churn pipeline.
Run: streamlit run app.py
Run python main.py first to create artifacts/best_churn_pipeline.joblib.
"""
from pathlib import Path
import json
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "artifacts" / "best_churn_pipeline.joblib"
META_PATH = ROOT / "artifacts" / "model_metadata.json"

st.set_page_config(page_title="Telecom Churn Predictor", page_icon="📡", layout="wide")

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None, None
    model = joblib.load(MODEL_PATH)
    metadata = json.loads(META_PATH.read_text()) if META_PATH.exists() else {}
    return model, metadata

model, metadata = load_model()

st.title("📡 Telecom Customer Churn Prediction")
st.caption("Machine Learning • Comparative Classification Analysis")
st.markdown(
    "Predict whether a telecom customer is likely to leave the service. "
    "Enter the customer's service and account details below."
)

with st.expander("About this project", expanded=True):
    st.write(
        "This application uses the best-performing model selected from Logistic Regression, "
        "Decision Tree, Random Forest, and the tuned Random Forest experiment. "
        "The complete preprocessing pipeline is saved with the model."
    )

if model is None:
    st.error("Trained model not found. Download the dataset, run `python main.py`, then restart this app.")
    st.stop()

with st.sidebar:
    st.header("Model information")
    st.write("Selected model:", metadata.get("best_model_name", "See training output"))
    metrics = metadata.get("test_metrics", {})
    if metrics:
        st.metric("Test F1-score", f"{metrics.get('F1-score', 0):.3f}")
        st.metric("Test ROC-AUC", f"{metrics.get('ROC-AUC', 0):.3f}")
        st.metric("Test accuracy", f"{metrics.get('Accuracy', 0):.3f}")
    st.caption("Metrics are generated from the held-out test set by main.py.")

st.subheader("Customer details")
with st.form("customer_form"):
    c1, c2, c3 = st.columns(3)
    with c1:
        gender = st.selectbox("Gender", ["Female", "Male"])
        senior = st.selectbox("Senior citizen", [0, 1], format_func=lambda x: "Yes" if x else "No")
        partner = st.selectbox("Has partner?", ["Yes", "No"])
        dependents = st.selectbox("Has dependents?", ["Yes", "No"])
        tenure = st.slider("Tenure (months)", 0, 72, 12)
        phone = st.selectbox("Phone service", ["Yes", "No"])
        multiple = st.selectbox("Multiple lines", ["No phone service", "No", "Yes"])
    with c2:
        internet = st.selectbox("Internet service", ["DSL", "Fiber optic", "No"])
        online_security = st.selectbox("Online security", ["No", "Yes", "No internet service"])
        online_backup = st.selectbox("Online backup", ["No", "Yes", "No internet service"])
        device_protection = st.selectbox("Device protection", ["No", "Yes", "No internet service"])
        tech_support = st.selectbox("Tech support", ["No", "Yes", "No internet service"])
        streaming_tv = st.selectbox("Streaming TV", ["No", "Yes", "No internet service"])
        streaming_movies = st.selectbox("Streaming movies", ["No", "Yes", "No internet service"])
    with c3:
        contract = st.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
        paperless = st.selectbox("Paperless billing", ["Yes", "No"])
        payment = st.selectbox("Payment method", [
            "Electronic check", "Mailed check",
            "Bank transfer (automatic)", "Credit card (automatic)"
        ])
        monthly = st.number_input("Monthly charges", min_value=0.0, max_value=200.0, value=70.0, step=1.0)
        total = st.number_input("Total charges", min_value=0.0, max_value=10000.0, value=840.0, step=10.0)
    submitted = st.form_submit_button("Predict churn", type="primary")

if submitted:
    customer = pd.DataFrame([{
        "gender": gender, "SeniorCitizen": senior, "Partner": partner,
        "Dependents": dependents, "tenure": tenure, "PhoneService": phone,
        "MultipleLines": multiple, "InternetService": internet,
        "OnlineSecurity": online_security, "OnlineBackup": online_backup,
        "DeviceProtection": device_protection, "TechSupport": tech_support,
        "StreamingTV": streaming_tv, "StreamingMovies": streaming_movies,
        "Contract": contract, "PaperlessBilling": paperless,
        "PaymentMethod": payment, "MonthlyCharges": monthly, "TotalCharges": total
    }])
    prediction = int(model.predict(customer)[0])
    probability = float(model.predict_proba(customer)[0, 1])
    st.divider()
    if prediction == 1:
        st.error("Prediction: YES — customer is likely to churn.")
    else:
        st.success("Prediction: NO — customer is less likely to churn.")
    st.metric("Estimated churn probability", f"{probability:.1%}")
    st.progress(min(max(probability, 0.0), 1.0))
    st.caption("This is a machine-learning estimate, not a guarantee of customer behaviour.")

st.divider()
st.subheader("Model performance")
if metrics:
    m1, m2, m3, m4, m5 = st.columns(5)
    for col, label, key in zip(
        [m1, m2, m3, m4, m5],
        ["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"],
        ["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"]
    ):
        col.metric(label, f"{metrics.get(key, 0):.3f}")
else:
    st.info("Run model training to populate performance metrics.")

plot_dir = ROOT / "visualizations"
if (plot_dir / "07_accuracy_comparison.png").exists():
    st.subheader("Training visualizations")
    p1, p2 = st.columns(2)
    p1.image(str(plot_dir / "07_accuracy_comparison.png"), use_container_width=True)
    p2.image(str(plot_dir / "08_f1_comparison.png"), use_container_width=True)
    st.image(str(plot_dir / "10_roc_curves.png"), use_container_width=True)
