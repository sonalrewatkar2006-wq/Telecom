# Telecom Customer Churn Prediction Using Machine Learning

Comparative analysis of exactly three baseline classifiers:
1. Logistic Regression
2. Decision Tree Classifier
3. Random Forest Classifier

A GridSearchCV experiment tunes Random Forest. A Streamlit application loads the saved best preprocessing-and-model pipeline to predict customer churn.

## 1. Dataset

Download **IBM Telco Customer Churn** from:
https://www.kaggle.com/datasets/blastchar/telco-customer-churn

Place the CSV file at:

`data/WA_Fn-UseC_-Telco-Customer-Churn.csv`

Do not commit customer-level data to a public repository unless you have checked the dataset licence and your institution's data policy.

## 2. Setup

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## 3. Train and evaluate

```bash
python main.py
```

The script prints dataset inspection and model results, and creates:
- `artifacts/best_churn_pipeline.joblib`
- `artifacts/best_model.joblib`
- `artifacts/model_metadata.json`
- `reports/baseline_model_comparison.csv`
- `reports/random_forest_tuning_comparison.csv`
- `reports/best_parameters.json`
- `reports/best_model_classification_report.txt`
- `reports/eda_summary.json`
- PNG figures in `visualizations/`

The train/test split is stratified (80/20, random state 42). All imputing, scaling and one-hot encoding are inside Scikit-learn pipelines. GridSearchCV uses only the training set with 5-fold stratified cross-validation.

The final model is selected using held-out test F1-score, with ROC-AUC as a tie-breaker. Test metrics are used for final comparison only; they are not used in tuning.

## 4. Run Streamlit

After training:

```bash
streamlit run app.py
```

Open the local URL shown in the terminal (usually http://localhost:8501).

## 5. Workflow

```mermaid
flowchart TD
    A[Kaggle IBM Telco CSV] --> B[Inspect, clean and EDA]
    B --> C[Remove customerID; convert TotalCharges]
    C --> D[Stratified train-test split]
    D --> E[Preprocessing pipeline: impute, scale, one-hot encode]
    E --> F[Train 3 baseline classifiers]
    F --> G[Evaluate: Accuracy, Precision, Recall, F1, ROC-AUC]
    E --> H[Random Forest GridSearchCV on training data]
    H --> I[Evaluate tuned Random Forest on test data]
    G --> J[Compare models and select best]
    I --> J
    J --> K[Save complete pipeline]
    K --> L[Streamlit customer churn prediction]
```

## 6. Important methodological notes

- `customerID` is removed because it is an identifier, not a useful customer behaviour feature.
- Blank `TotalCharges` values are converted to missing values and imputed inside the pipeline.
- Duplicate rows are removed.
- IQR outlier counts are reported for numerical variables. They are not automatically deleted because high tenure/charges can be legitimate customer records.
- Class weighting is used to reduce the effect of class imbalance without resampling the test set.
- ROC-AUC uses predicted probabilities; confusion matrices use class predictions.

## 7. GitHub upload

1. Create a new GitHub repository, e.g. `telecom-customer-churn-ml`.
2. Extract this project folder.
3. Add the dataset locally to `data/` (the dataset is not included in this code package).
4. Run training and verify that the `artifacts/`, `reports/`, and `visualizations/` outputs are created.
5. Review `.gitignore`. Decide whether to commit generated model artifacts. For a college submission, include them if repository size and institutional rules permit.
6. In the project folder, run:

```bash
git init
git add .
git commit -m "Add telecom churn prediction project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/telecom-customer-churn-ml.git
git push -u origin main
```

Or use GitHub website: **Add file → Upload files**, drag the project contents (not the outer folder), then commit.

## 8. Reproducibility

Use the same Python environment and dataset version. The random seed is fixed at 42. GridSearchCV can take several minutes depending on the computer.
