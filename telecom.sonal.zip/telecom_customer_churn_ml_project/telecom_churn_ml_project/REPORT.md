# Telecom Customer Churn Prediction Using Machine Learning
## A Comparative Performance Analysis of Classification Models

**Student Name:** ____________________  
**Roll Number:** ____________________  
**Class / Division:** ____________________  
**Department:** ____________________  
**College:** ____________________  
**Academic Year:** ____________________  
**Guide / Faculty:** ____________________

> **Submission note:** Run `python main.py` with the Kaggle CSV before final submission. Replace every `[AUTO-FILL AFTER RUN]` field below using the generated CSV/JSON outputs. No model scores are pre-filled because they must come from an actual run on the downloaded dataset.

## 1. Abstract
Customer churn occurs when a customer discontinues a service. This project applies supervised machine learning to predict churn in a telecommunications customer dataset. Logistic Regression, Decision Tree and Random Forest are trained using the same stratified training/testing split. Their performance is compared using accuracy, precision, recall, F1-score and ROC-AUC. Random Forest is further optimized using GridSearchCV with cross-validation restricted to the training data. The selected preprocessing-and-model pipeline is saved and integrated into a Streamlit application for interactive predictions.

## 2. Literature Review
Customer churn prediction is a common classification problem in subscription-based industries. Prior applied work commonly uses customer demographics, service subscriptions, contract details, billing information and tenure as predictive attributes. Logistic Regression provides an interpretable linear baseline; Decision Trees model non-linear decision rules; Random Forest combines multiple trees to improve robustness. This project compares these three established classifiers on one public telecom churn dataset and evaluates them with multiple classification metrics rather than accuracy alone.

## 3. Introduction and Problem Statement
Telecom providers face revenue loss when customers leave their service. Identifying customers who are likely to churn can help a provider prioritize retention activities. The problem is formulated as binary classification: predict `Churn = Yes` or `Churn = No` from customer account and service attributes.

## 4. Objectives
- Inspect and understand the IBM Telco Customer Churn dataset.
- Perform EDA using Matplotlib and Seaborn.
- Clean and preprocess numerical and categorical features without data leakage.
- Train exactly three baseline classifiers.
- Compare their classification performance using common metrics.
- Tune Random Forest using GridSearchCV and training-only cross-validation.
- Deploy the selected model in an interactive Streamlit application.

## 5. Dataset Description
**Dataset:** IBM Telco Customer Churn  
**Source:** https://www.kaggle.com/datasets/blastchar/telco-customer-churn  
**Target:** `Churn` (`Yes` / `No`)  
**Identifier removed:** `customerID`

The data contains customer demographic information, subscribed services, account details, contract type, payment method, tenure and charges. The supplied CSV contains one row per customer. Exact row/column counts are printed by `main.py` and recorded in `reports/eda_summary.json`.

## 6. EDA and Visualizations
The implementation generates the following figures in `visualizations/`:
1. `01_churn_distribution.png` — number of churned and retained customers.
2. `02_numeric_distributions.png` — tenure and monthly charges distributions split by churn.
3. `03_categorical_churn.png` — contract type and payment method against churn.
4. `04_tenure_boxplot.png` — tenure spread by churn status.
5. `05_correlation_heatmap.png` — correlations among numerical attributes and target.
6. `06_internet_service_churn_rate.png` — churn rate by internet service.
7. `07_accuracy_comparison.png` — baseline and tuned model accuracy.
8. `08_f1_comparison.png` — baseline and tuned model F1-score.
9. `09_confusion_matrices.png` — confusion matrices for each model.
10. `10_roc_curves.png` — ROC curves for each model.

**Observations to report after execution:**  
- Churn class balance: [AUTO-FILL from `eda_summary.json`].  
- Tenure pattern: [DESCRIBE from `02_numeric_distributions.png` and `04_tenure_boxplot.png`].  
- Contract/payment patterns: [DESCRIBE from `03_categorical_churn.png`].  
- Numerical relationships: [DESCRIBE from `05_correlation_heatmap.png`].  
Do not infer exact percentages from visual impressions; use the dataset or generated summary.

## 7. Data Preprocessing
- Duplicate rows are identified and removed.
- `customerID` is removed because it is a unique identifier.
- `TotalCharges` is converted from text to numeric; blank/non-numeric entries become missing values.
- Missing numerical values are imputed using the median.
- Missing categorical values are imputed using the most frequent category.
- Categorical columns are one-hot encoded with unknown-category handling.
- Numerical columns are standardized.
- The target is mapped to 0 (`No`) and 1 (`Yes`).
- Data is split into 80% training and 20% testing using stratification and random state 42.
- All preprocessing is contained inside Scikit-learn pipelines and is fitted only on training folds/data.
- IQR outliers are counted for diagnostics, not automatically removed, because extreme tenure and charges may be valid observations.
- Class weights are used in the classifiers to account for the minority churn class.

## 8. Algorithms Implemented
### 8.1 Logistic Regression
A linear classification model that estimates churn probability from a weighted combination of input features. It is used as a baseline and uses class weighting.

### 8.2 Decision Tree Classifier
A tree-based classifier that learns feature-based decision rules. It can model non-linear relationships and uses class weighting.

### 8.3 Random Forest Classifier
An ensemble of decision trees whose predictions are combined. The baseline uses 300 trees and balanced-sub-sample class weights.

## 9. Experimental Setup and Workflow
- Language: Python
- Libraries: Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, Joblib and Streamlit
- Split: stratified 80:20
- Random state: 42
- Baseline classifiers: same train/test split
- Hyperparameter tuning: 5-fold StratifiedKFold, F1 scoring, training data only

### ML Workflow
```mermaid
flowchart TD
 A[IBM Telco CSV] --> B[Data inspection and EDA]
 B --> C[Cleaning and feature selection]
 C --> D[Stratified 80:20 split]
 D --> E[Imputation, scaling and encoding pipeline]
 E --> F[Logistic Regression]
 E --> G[Decision Tree]
 E --> H[Random Forest]
 H --> I[GridSearchCV on training data]
 F --> J[Held-out test evaluation]
 G --> J
 H --> J
 I --> J
 J --> K[Compare metrics and select model]
 K --> L[Save model pipeline]
 L --> M[Streamlit app]
```

## 10. Performance Evaluation and Comparison
The following metrics are calculated on the held-out test set:
- **Accuracy:** proportion of all correct predictions.
- **Precision:** proportion of predicted churners who actually churned.
- **Recall:** proportion of actual churners correctly identified.
- **F1-score:** harmonic mean of precision and recall.
- **ROC-AUC:** ability to rank churners above non-churners across thresholds.
- **Confusion matrix:** counts of true negatives, false positives, false negatives and true positives.

**Actual baseline results:**  
Copy the table from `reports/baseline_model_comparison.csv` after running the script.

| Model | Accuracy | Precision | Recall | F1-score | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] |
| Decision Tree | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] |
| Random Forest | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] | [AUTO-FILL] |

## 11. Hyperparameter Tuning
GridSearchCV is applied to Random Forest. The search tests:
- `n_estimators`: 200, 400
- `max_depth`: None, 12, 24
- `min_samples_split`: 2, 5
- `min_samples_leaf`: 1, 2

Five-fold stratified cross-validation is performed only on the training set, optimizing F1-score. The best configuration is saved in `reports/best_parameters.json`.

**Before vs after tuning:** copy `reports/random_forest_tuning_comparison.csv`.  
**Best cross-validation F1:** [AUTO-FILL from terminal output].  
**Best parameters:** [AUTO-FILL from `best_parameters.json`].

## 12. Streamlit Deployment
The application is launched using `streamlit run app.py`. It provides a customer input form, Yes/No churn prediction, estimated churn probability, selected model information, test metrics and saved comparison visualizations. The full preprocessing-and-model pipeline is loaded from `artifacts/best_churn_pipeline.joblib`, ensuring the same transformations are applied during inference.

## 13. Results and Discussion
**Selected model:** [AUTO-FILL from `artifacts/model_metadata.json`].  
**Test metrics:** [AUTO-FILL from the same JSON].  
The final model is selected using test F1-score as the primary criterion and ROC-AUC as the tie-breaker. F1-score is emphasized because churn is typically a minority class and both missed churners and false churn alerts matter. Discuss the actual confusion matrix and ROC curve generated by the run. Do not claim tuning improved performance unless the before/after test results demonstrate an improvement.

## 14. Conclusion and Future Scope
This project implements an end-to-end churn prediction workflow, from data inspection and leakage-safe preprocessing to model comparison, Random Forest tuning and interactive deployment. The actual best classifier and its effectiveness are determined by executing the experiment on the downloaded dataset. Future scope includes testing on newer telecom data, monitoring prediction quality over time, and evaluating retention actions using business outcomes.

## 15. References
1. IBM Telco Customer Churn dataset, Kaggle: https://www.kaggle.com/datasets/blastchar/telco-customer-churn
2. Scikit-learn documentation: https://scikit-learn.org/stable/
3. Pandas documentation: https://pandas.pydata.org/docs/
4. Matplotlib documentation: https://matplotlib.org/stable/
5. Seaborn documentation: https://seaborn.pydata.org/
6. Streamlit documentation: https://docs.streamlit.io/
