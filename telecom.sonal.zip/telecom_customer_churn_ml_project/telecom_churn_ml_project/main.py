"""
Telecom Customer Churn Prediction
Run: python main.py
Input: data/WA_Fn-UseC_-Telco-Customer-Churn.csv
Outputs: artifacts/, visualizations/, reports/
"""
from pathlib import Path
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, classification_report, RocCurveDisplay
)

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "WA_Fn-UseC_-Telco-Customer-Churn.csv"
ARTIFACTS = ROOT / "artifacts"
PLOTS = ROOT / "visualizations"
REPORTS = ROOT / "reports"
for folder in (ARTIFACTS, PLOTS, REPORTS):
    folder.mkdir(exist_ok=True)

RANDOM_STATE = 42
TEST_SIZE = 0.20
TARGET = "Churn"
sns.set_theme(style="whitegrid", context="notebook")


def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_PATH}\n"
            "Download the IBM Telco Customer Churn CSV from Kaggle and save it as:\n"
            "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"
        )
    df = pd.read_csv(DATA_PATH)
    required = {TARGET, "customerID"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Unexpected dataset: required columns missing: {missing}")
    return df


def inspect_and_clean(df):
    print("\\n--- DATASET OVERVIEW ---")
    print("Shape:", df.shape)
    print("\\nFirst five rows:\\n", df.head())
    print("\\nData types:\\n", df.dtypes)
    print("\\nStatistical summary:\\n", df.describe(include="all").T)
    print("\\nMissing values before cleaning:\\n", df.isna().sum())
    print("\\nDuplicate rows:", int(df.duplicated().sum()))

    data = df.copy()
    data = data.drop_duplicates().copy()
    data = data.drop(columns=["customerID"], errors="ignore")
    # TotalCharges is stored as text in the source CSV; blank strings become NaN.
    data["TotalCharges"] = pd.to_numeric(data["TotalCharges"], errors="coerce")
    data[TARGET] = data[TARGET].map({"No": 0, "Yes": 1})
    if data[TARGET].isna().any():
        raise ValueError("Target contains values other than Yes/No.")
    print("\\nMissing values after type conversion:\\n", data.isna().sum())
    return data


def save_eda(data):
    # Churn class distribution
    plt.figure(figsize=(6, 4))
    ax = sns.countplot(data=data, x=TARGET)
    ax.set(title="Customer Churn Distribution", xlabel="Churn (0 = No, 1 = Yes)", ylabel="Number of customers")
    plt.tight_layout(); plt.savefig(PLOTS / "01_churn_distribution.png", dpi=160); plt.close()

    # Tenure and monthly charges by churn
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    sns.histplot(data=data, x="tenure", hue=TARGET, bins=30, kde=True, element="step", ax=axes[0])
    axes[0].set(title="Tenure Distribution by Churn", xlabel="Tenure (months)")
    sns.histplot(data=data, x="MonthlyCharges", hue=TARGET, bins=30, kde=True, element="step", ax=axes[1])
    axes[1].set(title="Monthly Charges by Churn", xlabel="Monthly charges")
    plt.tight_layout(); plt.savefig(PLOTS / "02_numeric_distributions.png", dpi=160); plt.close()

    # Contract and payment method versus churn
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    sns.countplot(data=data, x="Contract", hue=TARGET, ax=axes[0])
    axes[0].set(title="Contract Type vs Churn", xlabel="Contract type", ylabel="Customers")
    axes[0].tick_params(axis="x", rotation=15)
    sns.countplot(data=data, x="PaymentMethod", hue=TARGET, ax=axes[1])
    axes[1].set(title="Payment Method vs Churn", xlabel="Payment method", ylabel="Customers")
    axes[1].tick_params(axis="x", rotation=25)
    plt.tight_layout(); plt.savefig(PLOTS / "03_categorical_churn.png", dpi=160); plt.close()

    # Tenure by churn
    plt.figure(figsize=(7, 4))
    sns.boxplot(data=data, x=TARGET, y="tenure")
    plt.title("Tenure by Churn Status"); plt.xlabel("Churn (0 = No, 1 = Yes)")
    plt.tight_layout(); plt.savefig(PLOTS / "04_tenure_boxplot.png", dpi=160); plt.close()

    # Numeric correlation heatmap (includes target)
    numeric = data.select_dtypes(include=np.number)
    plt.figure(figsize=(10, 7))
    sns.heatmap(numeric.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Heatmap of Numeric Features")
    plt.tight_layout(); plt.savefig(PLOTS / "05_correlation_heatmap.png", dpi=160); plt.close()

    # Internet service and churn rate
    churn_rate = data.groupby("InternetService", dropna=False)[TARGET].mean().sort_values(ascending=False)
    plt.figure(figsize=(7, 4))
    sns.barplot(x=churn_rate.index, y=churn_rate.values)
    plt.title("Churn Rate by Internet Service")
    plt.xlabel("Internet service"); plt.ylabel("Churn rate")
    plt.ylim(0, 1)
    plt.tight_layout(); plt.savefig(PLOTS / "06_internet_service_churn_rate.png", dpi=160); plt.close()

    # IQR outlier counts are reported, not automatically removed: tenure/charges are valid customer behaviour.
    outlier_summary = {}
    for col in ["tenure", "MonthlyCharges", "TotalCharges"]:
        s = data[col].dropna()
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        count = int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())
        outlier_summary[col] = count
    with open(REPORTS / "eda_summary.json", "w") as f:
        json.dump({
            "rows_after_duplicate_removal": int(data.shape[0]),
            "columns_after_customer_id_removal": int(data.shape[1]),
            "missing_values": {k: int(v) for k, v in data.isna().sum().items()},
            "outlier_counts_iqr_diagnostic_only": outlier_summary,
            "churn_rate": float(data[TARGET].mean())
        }, f, indent=2)


def build_preprocessor(X):
    numeric_features = X.select_dtypes(include=np.number).columns.tolist()
    categorical_features = X.select_dtypes(exclude=np.number).columns.tolist()

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, numeric_features),
        ("categorical", categorical_pipe, categorical_features)
    ])


def evaluate(model, X_test, y_test, name):
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]
    return {
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1-score": f1_score(y_test, pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, prob)
    }


def save_evaluation_plots(models, X_test, y_test, comparison):
    # Accuracy and F1 comparison
    for metric, filename, title in [
        ("Accuracy", "07_accuracy_comparison.png", "Model Accuracy Comparison"),
        ("F1-score", "08_f1_comparison.png", "Model F1-score Comparison")
    ]:
        plt.figure(figsize=(8, 4))
        sns.barplot(data=comparison, x="Model", y=metric)
        plt.ylim(0, 1); plt.title(title); plt.ylabel(metric); plt.xlabel("Model")
        plt.xticks(rotation=12)
        plt.tight_layout(); plt.savefig(PLOTS / filename, dpi=160); plt.close()

    # Confusion matrices and ROC curves
    fig, axes = plt.subplots(1, len(models), figsize=(5 * len(models), 4))
    for ax, (name, model) in zip(axes, models.items()):
        cm = confusion_matrix(y_test, model.predict(X_test))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax)
        ax.set(title=f"Confusion Matrix: {name}", xlabel="Predicted", ylabel="Actual")
    plt.tight_layout(); plt.savefig(PLOTS / "09_confusion_matrices.png", dpi=160); plt.close()

    plt.figure(figsize=(7, 6))
    for name, model in models.items():
        RocCurveDisplay.from_estimator(model, X_test, y_test, name=name)
    plt.plot([0, 1], [0, 1], "k--", label="Chance")
    plt.title("ROC Curves"); plt.tight_layout()
    plt.savefig(PLOTS / "10_roc_curves.png", dpi=160); plt.close()


def main():
    raw = load_data()
    data = inspect_and_clean(raw)
    save_eda(data)

    X = data.drop(columns=[TARGET])
    y = data[TARGET].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
    )
    preprocessor = build_preprocessor(X_train)

    # Exactly three baseline classifiers; all preprocessing is fitted inside each pipeline.
    baseline_specs = {
        "Logistic Regression": LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(
            class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, class_weight="balanced_subsample",
            random_state=RANDOM_STATE, n_jobs=-1
        )
    }
    models = {}
    rows = []
    for name, classifier in baseline_specs.items():
        pipe = Pipeline([("preprocess", build_preprocessor(X_train)), ("model", classifier)])
        pipe.fit(X_train, y_train)
        models[name] = pipe
        rows.append(evaluate(pipe, X_test, y_test, name))

    baseline_results = pd.DataFrame(rows).sort_values("F1-score", ascending=False)
    baseline_results.to_csv(REPORTS / "baseline_model_comparison.csv", index=False)
    print("\\n--- BASELINE TEST RESULTS ---\\n", baseline_results.to_string(index=False))

    # Tune only Random Forest. CV sees training data only; preprocessing remains inside the pipeline.
    rf_pipeline = Pipeline([
        ("preprocess", build_preprocessor(X_train)),
        ("model", RandomForestClassifier(
            class_weight="balanced_subsample", random_state=RANDOM_STATE, n_jobs=-1
        ))
    ])
    param_grid = {
        "model__n_estimators": [200, 400],
        "model__max_depth": [None, 12, 24],
        "model__min_samples_split": [2, 5],
        "model__min_samples_leaf": [1, 2]
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    search = GridSearchCV(
        rf_pipeline, param_grid=param_grid, scoring="f1",
        cv=cv, n_jobs=-1, verbose=1, refit=True
    )
    search.fit(X_train, y_train)
    tuned_rf = search.best_estimator_
    tuned_metrics = evaluate(tuned_rf, X_test, y_test, "Tuned Random Forest")
    before_rf = baseline_results.loc[baseline_results["Model"] == "Random Forest"].iloc[0].to_dict()
    tuning_comparison = pd.DataFrame([
        {**before_rf},
        tuned_metrics
    ])
    tuning_comparison.to_csv(REPORTS / "random_forest_tuning_comparison.csv", index=False)
    with open(REPORTS / "best_parameters.json", "w") as f:
        json.dump(search.best_params_, f, indent=2)

    print("\\n--- RANDOM FOREST BEFORE / AFTER TUNING ---\\n", tuning_comparison.to_string(index=False))
    print("\\nBest CV F1:", search.best_score_)
    print("Best parameters:", search.best_params_)

    all_models = {**models, "Tuned Random Forest": tuned_rf}
    save_evaluation_plots(all_models, X_test, y_test, pd.concat(
        [baseline_results, pd.DataFrame([tuned_metrics])], ignore_index=True
    ))

    # Select best model using test F1 as primary metric; ROC-AUC breaks ties.
    final_results = pd.concat([baseline_results, pd.DataFrame([tuned_metrics])], ignore_index=True)
    best_row = final_results.sort_values(["F1-score", "ROC-AUC"], ascending=False).iloc[0]
    best_name = best_row["Model"]
    best_model = all_models[best_name]
    joblib.dump(best_model, ARTIFACTS / "best_churn_pipeline.joblib")
    joblib.dump(best_model, ARTIFACTS / "best_model.joblib")
    with open(ARTIFACTS / "model_metadata.json", "w") as f:
        json.dump({
            "best_model_name": best_name,
            "selection_metric": "F1-score (ROC-AUC tie-breaker)",
            "test_metrics": {k: float(v) for k, v in best_row.to_dict().items() if k != "Model"},
            "feature_columns": X.columns.tolist(),
            "random_state": RANDOM_STATE,
            "test_size": TEST_SIZE
        }, f, indent=2)

    # Machine-readable classification report for selected model.
    pred = best_model.predict(X_test)
    with open(REPORTS / "best_model_classification_report.txt", "w") as f:
        f.write(classification_report(y_test, pred, target_names=["No Churn", "Churn"]))
    print(f"\\nBEST MODEL: {best_name}")
    print("Artifacts saved to:", ARTIFACTS)
    print("Plots saved to:", PLOTS)
    print("Reports saved to:", REPORTS)


if __name__ == "__main__":
    main()
