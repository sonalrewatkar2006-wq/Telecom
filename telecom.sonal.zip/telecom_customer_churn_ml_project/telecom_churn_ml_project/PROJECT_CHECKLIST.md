# Final submission checklist

- [ ] Download the Kaggle CSV and place it in `data/`.
- [ ] Install dependencies from `requirements.txt`.
- [ ] Run `python main.py` successfully.
- [ ] Check `reports/baseline_model_comparison.csv`.
- [ ] Check `reports/random_forest_tuning_comparison.csv` and `best_parameters.json`.
- [ ] Check all 10 PNG figures in `visualizations/`.
- [ ] Run `streamlit run app.py` and test at least one customer input.
- [ ] Replace every `[AUTO-FILL AFTER RUN]` field in `REPORT.md`.
- [ ] Add student and college details.
- [ ] Include model artifacts and generated plots in the final repository.
- [ ] Confirm no unexpected dataset or personal information is committed.
